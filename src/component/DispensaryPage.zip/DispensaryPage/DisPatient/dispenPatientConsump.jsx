// src/components/ReportList.jsx
import React from 'react';
import "../DisPatient/dispenPatientConsump.css"

const DispenPatientConsump = () => {
 

  return (
    <div className="dPC-report-list">
      <h1>Sorry this page was not found!!</h1> 
    </div>
  );
};

export default DispenPatientConsump;