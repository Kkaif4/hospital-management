import React from 'react'
import "../SSPharmacy/sSPIssues.css"

function SSPIssues() {
  return (
    <div className="container">

      <h1>Sorry this page was not found!!</h1>
      {/* <div className="actions">
        <button className="btn-sale-to-patient">Sale To Patient</button>
        <button className="btn-consumption">Consumption</button>
      </div>
        <button className="btn-new-consumption"><i class="fa-solid fa-plus"></i> New Consumption</button>
      <div className="filter">
        <label htmlFor="select-ward">Select Ward:</label>
        <select id="select-ward">
          <option>Select...</option>
        </select>
      </div>
      <div className="results-header">
        <span>Showing 0 / 0 results</span>
        <button className="btn-print">Print</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>Patient Name</th>
            <th>Address</th>
            <th>Gender</th>
            <th>PhoneNumber</th>
            <th>Ward Name</th>
            <th>Quantity</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td colSpan="7" className="no-data">No Rows To Show</td>
          </tr>
        </tbody>
      </table>
      <div className="pagination">
        <span>0 to 0 of 0</span>
        <button disabled>First</button>
        <button disabled>Previous</button>
        <button className="active">Page 0 of 0</button>
        <button disabled>Next</button>
        <button disabled>Last</button>
      </div> */}
    </div>
  )
}

export default SSPIssues