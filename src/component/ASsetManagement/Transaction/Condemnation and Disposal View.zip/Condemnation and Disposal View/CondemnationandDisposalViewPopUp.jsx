import React, { useState, useRef } from 'react';
import { Calendar } from 'lucide-react';
import './CondemnationAnddisposalViewPopUp.css';
import { startResizing } from '../../../TableHeadingResizing/resizableColumns';

const CondemnationandDisposalViewPopUp = () => {
  const [activeTab, setActiveTab] = useState('proposal');
  const [proposalDetails, setProposalDetails] = useState([
    { sn: 1, equipmentName: '', type: 'New', assetNo: '', manualCode: '', location: '', category: '' }
  ]);
  const [approvedDetails, setApprovedDetails] = useState([
    { sn: 1, approvalBy: '', priority: '' }
  ]);

  const handleAddRow = (type) => {
    if (type === 'proposal') {
      setProposalDetails([
        ...proposalDetails,
        { sn: proposalDetails.length + 1, equipmentName: '', type: 'New', assetNo: '', manualCode: '', location: '', category: '' }
      ]);
    } else {
      setApprovedDetails([
        ...approvedDetails,
        { sn: approvedDetails.length + 1, approvalBy: '', priority: '' }
      ]);
    }
  };

  const handleDeleteRow = (type, index) => {
    if (type === 'proposal') {
      setProposalDetails(proposalDetails.filter((_, i) => i !== index));
    } else {
      setApprovedDetails(approvedDetails.filter((_, i) => i !== index));
    }
  };

  const [fileName, setFileName] = useState('');

  const handleChooseFileClick = () => {
    document.getElementById('fileInput').click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const [columnWidths, setColumnWidths] = useState({});
  const tableRef = useRef(null);

  return (
    <div className="CondemnationandDisposalViewPopUp-container">
      <div className="CondemnationandDisposalViewPopUp-header">
      Condemnation and Disposal
            </div>
      
      <div className="CondemnationandDisposalViewPopUp-form-container">
        <div className="CondemnationandDisposalViewPopUp-form-section">
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Condem No</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>



          <div className="CondemnationandDisposalViewPopUp-section-header">Equipment Info</div>


          {/* <div className="CondemnationandDisposalViewPopUp-status">
  <label className="CondemnationandDisposalViewPopUp-label">Capital Item :</label>
  <div className="CondemnationandDisposalViewPopUp-radio-buttons">
    <input
      type="radio"
      id="yes"
      name="status"
      value="yes"
    />
    <label htmlFor="yes">Yes</label>

    <input
      type="radio"
      id="no"
      name="status"
      value="no"
    />
    <label htmlFor="no">No</label>
  </div>
</div> */}


       
<div className="CondemnationandDisposalViewPopUp-form-group">
  <span className="CondemnationandDisposalViewPopUp-label">Name of Equipment<span className='CondemnationandDisposalViewPopUp-required'>*</span></span>
  <span className="CondemnationandDisposalViewPopUp-separator">:</span>
  <select className="CondemnationandDisposalViewPopUp-input-field">
    <option value="">Yes</option>
    <option value="">No</option>
  </select>
</div>
         

          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Asset Serial No</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>



          
        
        <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Author</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>


          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Location</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Approved Date</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="date" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Approved Time</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="time" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>

</div>




        <div className="CondemnationandDisposalViewPopUp-form-section">
       
        <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Make And Model</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Date Of Purchase</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="date" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Cost Of Purchase</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          
          





            {/* <div className="CondemnationandDisposalViewPopUp-section-header">Condemnation and Disposal Details</div> */}
            
            <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Life Recommended by Manufacturer</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Expenditure incurred on repairs	</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Total downtime in months	</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Expected cost of present repair	</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          
         

          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Name Of Proposer</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
          
         
          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Name Of Operator</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>
        </div>

        



        

        <div className="CondemnationandDisposalViewPopUp-form-section">
            
       


          
<div className="CondemnationandDisposalViewPopUp-form-group">
  <span className="CondemnationandDisposalViewPopUp-label">Reason For Condemnation<span className='CondemnationandDisposalViewPopUp-required'>*</span></span>
  <span className="CondemnationandDisposalViewPopUp-separator">:</span>
  <select className="CondemnationandDisposalViewPopUp-input-field">
    <option value="">Yes</option>
    <option value="">No</option>
  </select>
</div>

          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Name For Recommending</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>

          
         


          <div className="CondemnationandDisposalViewPopUp-form-group">
  <label className="CondemnationandDisposalViewPopUp-label"></label>
  <span className="CondemnationandDisposalViewPopUp-separator"></span>
  <div className="CondemnationandDisposalViewPopUp-input-container">
    <div className="CondemnationandDisposalViewPopUp-checkbox-group">
      <label className="CondemnationandDisposalViewPopUp-checkbox-label">
        <input type="checkbox" className="CondemnationandDisposalViewPopUp-checkbox" />
        Condemnation
      </label>
      <label className="CondemnationandDisposalViewPopUp-checkbox-label">
        <input type="checkbox" className="CondemnationandDisposalViewPopUp-checkbox" />
        Disposal
      </label>
    </div>
  </div>
</div>


<div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Remarks</span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>



              
          <div className="CondemnationandDisposalViewPopUp-form-group">
  <span className="CondemnationandDisposalViewPopUp-label">Type</span>
  <span className="CondemnationandDisposalViewPopUp-separator">:</span>
  <select className="CondemnationandDisposalViewPopUp-input-field">
    <option value="">Yes</option>
    <option value="">No</option>
  </select>
</div>

        

          <div className="CondemnationandDisposalViewPopUp-form-group">
            <span className="CondemnationandDisposalViewPopUp-label">Approve Remarks<span className='CondemnationandDisposalViewPopUp-required'>*</span></span>
            <span className="CondemnationandDisposalViewPopUp-separator">:</span>
            <input type="text" className="CondemnationandDisposalViewPopUp-input-field" />
          </div>

            <div className="CondemnationandDisposalViewPopUp-section-header">Attachment</div>
            <div className="CondemnationandDisposalViewPopUp-file-upload">
              <input
                type="text"
                className="CondemnationandDisposalViewPopUp-input-field"
                placeholder="File Name"
                value={fileName}
                readOnly
              />
              <input
                type="file"
                id="fileInput"
                style={{ display: 'none' }}
                onChange={handleFileChange}
              />
              <button
                className="CondemnationandDisposalViewPopUp-btn-secondary"
                onClick={handleChooseFileClick}
              >
                Choose File
              </button>
              <button className="CondemnationandDisposalViewPopUp-btn-secondary">Upload</button>
            </div>

 


        </div>
    




      </div>

      <div className="CondemnationandDisposalViewPopUp-tabs-section">
        <div className="CondemnationandDisposalViewPopUp-tab-buttons">
          <button
            className={`CondemnationandDisposalViewPopUp-tab-btn ${activeTab === 'proposal' ? 'active' : ''}`}
            onClick={() => setActiveTab('proposal')}
          >
          Details
          </button>

        </div>

        {activeTab === 'proposal' ? (
          <div className="CondemnationandDisposalViewPopUp-table-container">

            <table className="CondemnationandDisposalViewPopUp-data-table" ref={tableRef}>
  <thead>
    <tr>
      {[
        "Actions", // Move the "Actions" column to the front
        "SN",
        "Approved By",
       
      
      ].map((header, index) => (
        <th
          key={index}
          style={{ width: columnWidths[index] }}
          className="resizable-th"
        >
          <div className="header-content">
            <span>{header}</span>
            <div
              className="resizer"
              onMouseDown={startResizing(tableRef, setColumnWidths)(index)}
            ></div>
          </div>
        </th>
      ))}
    </tr>
  </thead>
  <tbody>
    {proposalDetails.map((row, index) => (
      <tr key={row.sn}>
        <td>
          <button
            className="CondemnationandDisposalViewPopUp-btn-add"
            onClick={() => handleAddRow('proposal')}
          >
            Add
          </button>
          <button
            className="CondemnationandDisposalViewPopUp-btn-delete"
            onClick={() => handleDeleteRow('proposal', index)}
          >
            Del
          </button>
        </td>
        <td>{row.sn}</td>
        <td><input type="text" /></td> {/* For Schedule Date */}
       
      </tr>
    ))}
  </tbody>
</table>
          </div>
        ) : (
          <div className="CondemnationandDisposalViewPopUp-table-container">
            <div className="CondemnationandDisposalViewPopUp-table-actions">
              <span>Existing Schedules</span>
            </div>


        <table className="CondemnationandDisposalViewPopUp-data-table" ref={tableRef}>
  <thead>
    <tr>
      {[
        "Actions",
        "SN",
        "Schedule Date",
        "EMaintenance Type",
        "ERemarks",
        "To Do",
      ].map((header, index) => (
        <th
          key={index}
          style={{ width: columnWidths[index] }}
          className="resizable-th"
        >
          <div className="header-content">
            <span>{header}</span>
            <div
              className="resizer"
              onMouseDown={startResizing(tableRef, setColumnWidths)(index)}
            ></div>
          </div>
        </th>
      ))}
    </tr>
  </thead>
  <tbody>
    {approvedDetails.map((row, index) => (
      <tr key={row.sn}>
        <td>
          <button 
            className="CondemnationandDisposalViewPopUp-btn-add" 
            onClick={() => handleAddRow('approved')}
          >
            Add
          </button>
          <button 
            className="CondemnationandDisposalViewPopUp-btn-delete"
            onClick={() => handleDeleteRow('approved', index)}
          >
            Del
          </button>
        </td>
        <td>{row.sn}</td>
        <td><input type="text" /></td> {/* Schedule Date */}
        <td><input type="text" /></td> {/* EMaintenance Type */}
        <td><input type="text" /></td> {/* ERemarks */}
        <td><input type="text" /></td> {/* To Do */}
      </tr>
    ))}
  </tbody>
</table>



          </div>
        )}
      </div>
      <button className="CondemnationandDisposalViewPopUp-btn-blue" >
            Save
          </button>
              </div>
  );
};

export default CondemnationandDisposalViewPopUp;