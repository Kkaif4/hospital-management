import React, { useState, useRef } from "react";
import { FaArrowCircleRight } from "react-icons/fa";
import { CiSearch } from "react-icons/ci";
import "./EquipmentGetPassOut.css";
import { startResizing } from "../../../../TableHeadingResizing/ResizableColumns";

const EquipmentGetPassOut = () => {
  const [selectedTab, setSelectedTab] = useState("itemDetails");
  const [columnWidths, setColumnWidths] = useState({});
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadMessage, setUploadMessage] = useState("");
  const tableRef = useRef(null);

  // State to manage table rows
  const [itemDetailsTableRows, setitemDetailsTableRows] = useState([
    {
      sn: 1,
      assetNo: "",
      equipment: "",
      partsName: "",
      serialNo: "",
      eqpNo: "",
      modelNo: "",
      qty: "",
      brand: "",
      location: "",
    },
  ]);

  const [nonRegisterItemsTableRows, setnonRegisterItemsTableRows] = useState([
    {
      sn: 1,
      itemDetails: "",
      qty: "",
      description: "",
    },
  ]);

  const [approveDetailsTableRows, setapproveDetailsTableRows] = useState([
    {
      sn: 1,
      approvalBy: "",
      priority: "",
    },
  ]);
  const handleAddRow = (tableType) => {
    if (tableType === "itemDetails") {
      const newRow = {
        sn: itemDetailsTableRows.length + 1,
        assetNo: "",
        equipment: "",
        partsName: "",
        serialNo: "",
        eqpNo: "",
        modelNo: "",
        qty: "",
        brand: "",
        location: "",
      };
      setitemDetailsTableRows([...itemDetailsTableRows, newRow]);
    } else if (tableType === "nonRegisterItems") {
      const newRow = {
        sn: nonRegisterItemsTableRows.length + 1,
        itemDetails: "",
        qty: "",
        description: "",
      };
      setnonRegisterItemsTableRows([...nonRegisterItemsTableRows, newRow]);
    } else if (tableType === "approveDetails") {
      const newRow = {
        sn: approveDetailsTableRows.length + 1,
        approvalBy: "",
        priority: "",
      };
      setapproveDetailsTableRows([...approveDetailsTableRows, newRow]);
    }
  };
  const handleDeleteRow = (tableType, indexToRemove) => {
    if (tableType === "itemDetails") {
      const updatedRows = itemDetailsTableRows.filter(
        (_, index) => index !== indexToRemove
      );
      const renumberedRows = updatedRows.map((row, index) => ({
        ...row,
        sn: index + 1,
      }));
      setitemDetailsTableRows(renumberedRows);
    } else if (tableType === "nonRegisterItems") {
      const updatedRows = nonRegisterItemsTableRows.filter(
        (_, index) => index !== indexToRemove
      );
      const renumberedRows = updatedRows.map((row, index) => ({
        ...row,
        sn: index + 1,
      }));
      setnonRegisterItemsTableRows(renumberedRows);
    } else if (tableType === "approveDetails") {
      const updatedRows = approveDetailsTableRows.filter(
        (_, index) => index !== indexToRemove
      );
      const renumberedRows = updatedRows.map((row, index) => ({
        ...row,
        sn: index + 1,
      }));
      setapproveDetailsTableRows(renumberedRows);
    }
  };
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      setUploadMessage("");
    }
  };
  const handleUpload = () => {
    if (!selectedFile) {
      setUploadMessage("Please select a file before uploading.");
      return;
    }
    setTimeout(() => {
      setUploadMessage(`File "${selectedFile.name}" uploaded successfully!`);
      setSelectedFile(null);
    }, 1000);
  };

  const renderTable = () => {
    switch (selectedTab) {
      case "itemDetails":
        return (
          <div className="EquipmentGetPassOut-itemDetails-table">
            <table border={1} ref={tableRef}>
              <thead>
                <tr>
                  {[
                    "",
                    "SN",
                    "Asset No",
                    "Equipment",
                    "Parts Name",
                    "Serial No",
                    "Eqp No",
                    "ModelNo",
                    "Qty",
                    "Brand",
                    "Location",
                  ].map((header, index) => (
                    <th
                      key={index}
                      style={{ width: columnWidths[index] }}
                      className="resizable-th"
                    >
                      <div className="header-content">
                        <span>{header}</span>
                        <div
                          className="resizer"
                          onMouseDown={startResizing(
                            tableRef,
                            setColumnWidths
                          )(index)}
                        ></div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {itemDetailsTableRows.map((row, index) => (
                  <tr key={index}>
                    <td>
                      <div className="table-actions">
                        <button
                          className="EquipmentGetPassOut-add-btn"
                          onClick={() => handleAddRow("itemDetails")}
                        >
                          Add
                        </button>
                        <button
                          className="EquipmentGetPassOut-del-btn"
                          onClick={() => handleDeleteRow("itemDetails", index)}
                          disabled={itemDetailsTableRows.length <= 1}
                        >
                          Del
                        </button>
                      </div>
                    </td>
                    <td>{row.sn}</td>
                    <td>{row.assetNo}</td>
                    <td>
                      {row.equipment}
                      <div className="EquipmentGetPassOut-input-with-search">
                        <input type="text" value="" />
                        <CiSearch className="EquipmentGetPassOut-magnifier-btn" />
                      </div>
                    </td>
                    <td>
                      {row.partsName}
                      <textarea name=""></textarea>
                    </td>
                    <td>{row.serialNo}</td>
                    <td>{row.eqpNo}</td>
                    <td>{row.modelNo}</td>
                    <td>{row.qty}</td>
                    <td>{row.brand}</td>
                    <td>{row.location}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case "nonRegisterItems":
        return (
          <div className="EquipmentGetPassOut-nonRegisterItems-table">
            <table border={1} ref={tableRef}>
              <thead>
                <tr>
                  {["", "SN", "Item Details", "Qty", "Description"].map(
                    (header, index) => (
                      <th
                        key={index}
                        style={{ width: columnWidths[index] }}
                        className="resizable-th"
                      >
                        <div className="header-content">
                          <span>{header}</span>
                          <div
                            className="resizer"
                            onMouseDown={(e) =>
                              startResizing(tableRef, setColumnWidths)(index, e)
                            } // Pass event to the handler
                          ></div>
                        </div>
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {nonRegisterItemsTableRows.map((row, index) => (
                  <tr key={index}>
                    <td>
                      <div className="table-actions">
                        <button
                          className="EquipmentGetPassOut-add-btn"
                          onClick={() => handleAddRow("nonRegisterItems")}
                        >
                          Add
                        </button>
                        <button
                          className="EquipmentGetPassOut-del-btn"
                          onClick={() =>
                            handleDeleteRow("nonRegisterItems", index)
                          }
                          disabled={nonRegisterItemsTableRows.length <= 1}
                        >
                          Del
                        </button>
                      </div>
                    </td>
                    <td>{row.sn}</td>
                    <td>{row.itemDetails}
                        <textarea></textarea>
                    </td>
                    <td>{row.qty}</td>
                    <td>{row.description}
                        <textarea></textarea>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case "approveDetails":
        return (
          <div className="EquipmentGetPassOut-approveDetails-table">
            <table border={1} ref={tableRef}>
              <thead>
                <tr>
                  {["", "SN", "Approval By", "Priority"].map(
                    (header, index) => (
                      <th
                        key={index}
                        style={{ width: columnWidths[index] }}
                        className="resizable-th"
                      >
                        <div className="header-content">
                          <span>{header}</span>
                          <div
                            className="resizer"
                            onMouseDown={startResizing(
                              tableRef,
                              setColumnWidths
                            )(index)}
                          ></div>
                        </div>
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {approveDetailsTableRows.map((row, index) => (
                  <tr key={index}>
                    <td>
                      <div className="table-actions">
                        <button
                          className="EquipmentGetPassOut-add-btn"
                          onClick={() => handleAddRow("approveDetails")}
                        >
                          Add
                        </button>
                        <button
                          className="EquipmentGetPassOut-del-btn"
                          onClick={() =>
                            handleDeleteRow("approveDetails", index)
                          }
                          disabled={approveDetailsTableRows.length <= 1}
                        >
                          Del
                        </button>
                      </div>
                    </td>
                    <td>{row.sn}</td>
                    <td>{row.approvalBy}
                    <div className="EquipmentGetPassOut-input-with-search">
                  <input type="text" value="" />
                  <CiSearch className="EquipmentGetPassOut-magnifier-btn" />
                </div>
                    </td>
                    <td>{row.priority}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="EquipmentGetPassOut-event">
      <div className="EquipmentGetPassOut-event-bar">
        <div className="EquipmentGetPassOut-event-header">
          <FaArrowCircleRight />
          <span>Equipment Get Pass Out</span>
        </div>
      </div>
      <div className="EquipmentGetPassOut-content-wrapper">
        <div className="EquipmentGetPassOut-main-section">
          <div className="EquipmentGetPassOut-panel dis-templates">
            <div className="EquipmentGetPassOut-panel-header"></div>
            <div className="EquipmentGetPassOut-panel-content">
              <div className="EquipmentGetPassOut-form-row">
                <label>Gate Pass Out No : </label>
                <input type="text" value="" />
              </div>

              <div className="EquipmentGetPassOut-header-contact">
                <h3>Equipment Out Details</h3>
              </div>
              <div className="EquipmentGetPassOut-form-row">
                <label>Supplier Name : </label>
                <div className="EquipmentGetPassOut-input-with-search">
                  <input type="text" value="" />

                  <CiSearch className="EquipmentGetPassOut-magnifier-btn" />
                </div>
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Asset No : </label>
                <input type="text" value="" />
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Recommended By : </label>
                <input type="text" value="" />
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Reason : </label>
                <textarea name="" id=""></textarea>
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Mode Of Transport : </label>
                <input type="text" value="" />
              </div>
              <div className="EquipmentGetPassOut-form-row">
                <label>Type : </label>
                <select>
                  <option>Returnable</option>
                  <option>Not-Returnable </option>
                  <option>Internal </option>
                  <option>Home Care</option>
                </select>
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Gate Pass out Date : </label>
                <input type="date" value="" />
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Gate pass out Time : </label>
                <input type="time" value="" />
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Serial No : </label>
                <input type="text" value="" />
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Model No : </label>
                <input type="text" value="" />
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Time Period : </label>
                <input type="text" value="" />
              </div>

              <div className="EquipmentGetPassOut-form-row">
                <label>Prepared By : </label>
                <input type="text" value="" />
              </div>
            </div>
          </div>

          <div className="EquipmentGetPassOut-panel operation-details">
            <div className="EquipmentGetPassOut-panel-header"></div>
            <div className="EquipmentGetPassOut-panel-content">
              <div className="EquipmentGetPassOut-form-row">
                <label>Received By : </label>
                <input type="text" value="" />
              </div>
              <div className="EquipmentGetPassOut-form-row">
                <label>Authorised By : </label>
                <input type="text" value="" />
              </div>
              <div className="EquipmentGetPassOut-form-row">
                <label>Type Of Equipment: </label>
                <select>
                  <option value="">Parts</option>
                  <option>Equipments </option>
                  <option>Stock Item </option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div className="EquipmentGetPassOut-approveDetails-section">
          <div className="EquipmentGetPassOut-tab-bar">
            <button
              className={`EquipmentGetPassOut-tab ${
                selectedTab === "itemDetails" ? "active" : ""
              }`}
              onClick={() => setSelectedTab("itemDetails")}
            >
              Item Details
            </button>

            <button
              className={`EquipmentGetPassOut-tab ${
                selectedTab === "nonRegisterItems" ? "active" : ""
              }`}
              onClick={() => setSelectedTab("nonRegisterItems")}
            >
              Non Register Items
            </button>
            <button
              className={`EquipmentGetPassOut-tab ${
                selectedTab === "approveDetails" ? "active" : ""
              }`}
              onClick={() => setSelectedTab("approveDetails")}
            >
              Approve Details
            </button>
          </div>
          {renderTable()}
        </div>

        <div className="EquipmentGetPassOut-action-buttons">
          <button className="btn-blue">Save</button>
          <button className="btn-red">Delete</button>
          <button className="btn-orange">Clear</button>
          <button className="btn-gray">Close</button>
          <button className="btn-blue">Search</button>
          <button className="btn-gray">Tracking</button>
          <button className="btn-green">Print</button>
          <button className="btn-blue">Export</button>
          <button className="btn-gray">Import</button>
          <button className="btn-green">Health</button>
          <button className="btn-gray">Version Comparison</button>
          <button className="btn-gray">SDC</button>
          <button className="btn-gray">Testing</button>
          <button className="btn-blue">Info</button>
        </div>
      </div>
    </div>
  );
};
export default EquipmentGetPassOut;
