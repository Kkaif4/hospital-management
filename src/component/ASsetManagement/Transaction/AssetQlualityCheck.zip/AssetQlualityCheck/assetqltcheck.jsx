import React, { useState } from "react";
import "./AssetsQualityCheck.css";

function AssetsQualityCheck() {
  const [formData, setFormData] = useState({
    recordNo: "",
    qualityCheckDate: "",
    nameOfEquipment: "",
    equipmentNo: "",
    assetNo: "",
    location: "",
    makeSerialNo: "",
    category: "",
    companyBrand: "",
    depreciation: "",
    modelNo: "",
    responsibilityPerson: "",
    poNo: "",
    poDate: "",
    invoiceNo: "",
    invoiceDate: "",
    amcFromDate: "",
    amcToDate: "",
    serviceCompany: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Submitted:", formData);
    // Add logic to handle form submission (e.g., API call)
  };

  return (
    <div className="assets-quality-check-container">
      <h3>Assets Quality Check</h3>
      <form className="assets-quality-check-form" onSubmit={handleSubmit}>
        <div className="assetqltform">
        <label>
          Record No:</label>
          <input
            type="text"
            name="recordNo"
            value={formData.recordNo}
            onChange={handleInputChange}
          />
        
        </div>
        <div className="assetqltform">
        <label>
          Quality Check Date:</label>
          <input
            type="date"
            name="qualityCheckDate"
            value={formData.qualityCheckDate}
            onChange={handleInputChange}
          />
       
        </div>
        <div className="assetqltform">
        <label>
          Name of Equipment:</label>
          <input
            type="text"
            name="nameOfEquipment"
            value={formData.nameOfEquipment}
            onChange={handleInputChange}
          />
       
        </div>
       <div className="assetqltform">
       <label>
          Equipment No:</label>
          <input
            type="text"
            name="equipmentNo"
            value={formData.equipmentNo}
            onChange={handleInputChange}
          />
        
       </div>
        <div className="assetqltform">
        <label>
          Asset No:</label>
          <input
            type="text"
            name="assetNo"
            value={formData.assetNo}
            onChange={handleInputChange}
          />
       
        </div>
       <div className="assetqltform">
       <label>
          Location:</label>
          <input
            type="text"
            name="location"
            value={formData.location}
            onChange={handleInputChange}
          />
       
       </div>
        <div className="assetqltform">
        <label>
          Make & Serial No:</label>
          <input
            type="text"
            name="makeSerialNo"
            value={formData.makeSerialNo}
            onChange={handleInputChange}
          />
        
        </div>
        <div className="assetqltform">
        <label>
          Category:</label>
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleInputChange}
          />
      
        </div>
        <div className="assetqltform">
        <label>
          Company Brand:</label>
          <input
            type="text"
            name="companyBrand"
            value={formData.companyBrand}
            onChange={handleInputChange}
          />
       
        </div>
       <div className="assetqltform">
       <label>
          Depreciation:</label>
          <input
            type="text"
            name="depreciation"
            value={formData.depreciation}
            onChange={handleInputChange}
          />
       
       </div>
       <div className="assetqltform">
       <label>
          Model No:</label>
          <input
            type="text"
            name="modelNo"
            value={formData.modelNo}
            onChange={handleInputChange}
          />
        
       </div>
        <div className="assetqltform">
        <label>
          Responsibility Person:</label>
          <input
            type="text"
            name="responsibilityPerson"
            value={formData.responsibilityPerson}
            onChange={handleInputChange}
          />
        
        </div>
        <div className="assetqltform">
        <label>
          PO No:</label>
          <input
            type="text"
            name="poNo"
            value={formData.poNo}
            onChange={handleInputChange}
          />
        
        </div>
        <div className="assetqltform">
        <label>
          PO Date:</label>
          <input
            type="date"
            name="poDate"
            value={formData.poDate}
            onChange={handleInputChange}
          />
        
        </div>
        <div className="assetqltform">
        <label>
          Invoice No:</label>
          <input
            type="text"
            name="invoiceNo"
            value={formData.invoiceNo}
            onChange={handleInputChange}
          />
        
        </div>
        <div className="assetqltform">
        <label>
          Invoice Date:</label>
          <input
            type="date"
            name="invoiceDate"
            value={formData.invoiceDate}
            onChange={handleInputChange}
          />
      
        </div>
        <div className="assetqltform">
        <label>
          AMC From Date: </label>
          <input
            type="date"
            name="amcFromDate"
            value={formData.amcFromDate}
            onChange={handleInputChange}
          />
        
        </div>
        <div className="assetqltform">
        <label>
          AMC To Date: </label>
          <input
            type="date"
            name="amcToDate"
            value={formData.amcToDate}
            onChange={handleInputChange}
          />
       
        </div>
        <div className="assetqltform">
        <label>
          AMC/CMC Service From Company: </label>
          <input
            type="text"
            name="serviceCompany"
            value={formData.serviceCompany}
            onChange={handleInputChange}
          />
       
        </div>
      
      </form>
      <button className="assetqltycheckbtn" type="submit">Submit</button>
    </div>
  );
}

export default AssetsQualityCheck;
