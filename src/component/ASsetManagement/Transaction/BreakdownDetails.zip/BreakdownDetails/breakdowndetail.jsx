import React, { useState, useRef } from "react";
import { FaArrowCircleRight } from "react-icons/fa";
import { CiSearch } from "react-icons/ci";
import "./BreakDownDetails.css";
import { startResizing } from "../../../../TableHeadingResizing/ResizableColumns";

const BreakDownDetails = () => {
  const [selectedTab, setSelectedTab] = useState("repairbleParts");
  const [columnWidths, setColumnWidths] = useState({});
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadMessage, setUploadMessage] = useState("");
  const tableRef = useRef(null);

  // State to manage table rows
  const [repairblePartsTableRows, setrepairblePartsTableRows] = useState([
    {
      sn: 1,
      date: "",
      partName: "",
      consumedTime: "",
      repairCost: "",
    },
  ]);

  const [guaranteedPartsTableRows, setguaranteedPartsTableRows] = useState([
    {
      sn: 1,
      date: "",
      partName: "",
      guranteedPeriod: "",
      cost: "",
    },
  ]);

  const [historyTableRows, sethistoryTableRows] = useState([
    {
      sn: 1,
      date: "",
      breakdownNo: "",
      parts: "",
      consumedTime: "",
      cost: "",
      partsDescription: "",
    },
  ]);

  // Function to add a row to the appropriate table
  const handleAddRow = (tableType) => {
    if (tableType === "repairbleParts") {
      const newRow = {
        sn: repairblePartsTableRows.length + 1,
        date: "",
        partName: "",
        consumedTime: "",
        repairCost: "",
      };
      setrepairblePartsTableRows([...repairblePartsTableRows, newRow]);
    } else if (tableType === "guaranteedParts") {
      const newRow = {
        sn: guaranteedPartsTableRows.length + 1,
        date: "",
        partName: "",
        guranteedPeriod: "",
        cost: "",
      };
      setguaranteedPartsTableRows([...guaranteedPartsTableRows, newRow]);
    } else if (tableType === "history") {
      const newRow = {
        sn: historyTableRows.length + 1,
        date: "",
        breakdownNo: "",
        parts: "",
        consumedTime: "",
        cost: "",
        partsDescription: "",
      };
      sethistoryTableRows([...historyTableRows, newRow]);
    }
  };

  // Function to delete a row from the appropriate table
  const handleDeleteRow = (tableType, indexToRemove) => {
    if (tableType === "repairbleParts") {
      const updatedRows = repairblePartsTableRows.filter(
        (_, index) => index !== indexToRemove
      );
      const renumberedRows = updatedRows.map((row, index) => ({
        ...row,
        sn: index + 1,
      }));
      setrepairblePartsTableRows(renumberedRows);
    } else if (tableType === "guaranteedParts") {
      const updatedRows = guaranteedPartsTableRows.filter(
        (_, index) => index !== indexToRemove
      );
      const renumberedRows = updatedRows.map((row, index) => ({
        ...row,
        sn: index + 1,
      }));
      setguaranteedPartsTableRows(renumberedRows);
    } else if (tableType === "history") {
      const updatedRows = historyTableRows.filter(
        (_, index) => index !== indexToRemove
      );
      const renumberedRows = updatedRows.map((row, index) => ({
        ...row,
        sn: index + 1,
      }));
      sethistoryTableRows(renumberedRows);
    }
  };
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      setUploadMessage(""); // Clear any previous upload messages
    }
  };

  // Handle file upload
  const handleUpload = () => {
    if (!selectedFile) {
      setUploadMessage("Please select a file before uploading.");
      return;
    }

    // Simulate upload (replace with actual upload logic)
    setTimeout(() => {
      setUploadMessage(`File "${selectedFile.name}" uploaded successfully!`);
      setSelectedFile(null); // Clear selected file after upload
    }, 1000); // Simulate upload delay
  };

  const renderTable = () => {
    switch (selectedTab) {
      case "repairbleParts":
        return (
          <div className="BreakDownDetails-repairbleParts-table">
            <table border={1} ref={tableRef}>
              <thead>
                <tr>
                  {[
                    "",
                    "SN",
                    "Date",
                    "Parts Name",
                    "Consumed Time",
                    "Repaire Cost",
                  ].map((header, index) => (
                    <th
                      key={index}
                      style={{ width: columnWidths[index] }}
                      className="resizable-th"
                    >
                      <div className="header-content">
                        <span>{header}</span>
                        <div
                          className="resizer"
                          onMouseDown={startResizing(
                            tableRef,
                            setColumnWidths
                          )(index)}
                        ></div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {repairblePartsTableRows.map((row, index) => (
                  <tr key={index}>
                    <td>
                      <div className="table-actions">
                        <button
                          className="BreakDownDetails-add-btn"
                          onClick={() => handleAddRow("repairbleParts")}
                        >
                          Add
                        </button>
                        <button
                          className="BreakDownDetails-del-btn"
                          onClick={() =>
                            handleDeleteRow("repairbleParts", index)
                          }
                          disabled={repairblePartsTableRows.length <= 1}
                        >
                          Del
                        </button>
                      </div>
                    </td>
                    <td>{row.sn}</td>
                    <td>{row.date}</td>
                    <td>{row.partName}</td>
                    <td>{row.consumedTime}</td>
                    <td>{row.repairCost}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case "guaranteedParts":
        return (
          <div className="BreakDownDetails-guaranteedParts-table">
            <table border={1} ref={tableRef}>
              <thead>
                <tr>
                  {[
                    "",
                    "SN",
                    "Date",
                    "Parts Name",
                    "Gurantee Period",
                    "Cost",
                  ].map((header, index) => (
                    <th
                      key={index}
                      style={{ width: columnWidths[index] }}
                      className="resizable-th"
                    >
                      <div className="header-content">
                        <span>{header}</span>
                        <div
                          className="resizer"
                          onMouseDown={(e) =>
                            startResizing(tableRef, setColumnWidths)(index, e)
                          } // Pass event to the handler
                        ></div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {guaranteedPartsTableRows.map((row, index) => (
                  <tr key={index}>
                    <td>
                      <div className="table-actions">
                        <button
                          className="BreakDownDetails-add-btn"
                          onClick={() => handleAddRow("guaranteedParts")}
                        >
                          Add
                        </button>
                        <button
                          className="BreakDownDetails-del-btn"
                          onClick={() =>
                            handleDeleteRow("guaranteedParts", index)
                          }
                          disabled={guaranteedPartsTableRows.length <= 1}
                        >
                          Del
                        </button>
                      </div>
                    </td>
                    <td>{row.sn}</td>
                    <td>{row.date}</td>
                    <td>{row.partName}</td>
                    <td>{row.guranteedPeriod}</td>
                    <td>{row.cost}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case "history":
        return (
          <div className="BreakDownDetails-history-table">
            <table border={1} ref={tableRef}>
              <thead>
                <tr>
                  {[
                    "",
                    "SN",
                    "Date",
                    "Breakdown No",
                    "Parts",
                    "Consumed Time",
                    "Cost",
                    "Parts Description",
                  ].map((header, index) => (
                    <th
                      key={index}
                      style={{ width: columnWidths[index] }}
                      className="resizable-th"
                    >
                      <div className="header-content">
                        <span>{header}</span>
                        <div
                          className="resizer"
                          onMouseDown={startResizing(
                            tableRef,
                            setColumnWidths
                          )(index)}
                        ></div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {historyTableRows.map((row, index) => (
                  <tr key={index}>
                    <td>
                      <div className="table-actions">
                        <button
                          className="BreakDownDetails-add-btn"
                          onClick={() => handleAddRow("history")}
                        >
                          Add
                        </button>
                        <button
                          className="BreakDownDetails-del-btn"
                          onClick={() => handleDeleteRow("history", index)}
                          disabled={historyTableRows.length <= 1}
                        >
                          Del
                        </button>
                      </div>
                    </td>
                    <td>{row.sn}</td>
                    <td>{row.date}</td>
                    <td>{row.breakdownNo}</td>
                    <td>{row.parts}</td>
                    <td>{row.consumedTime}</td>
                    <td>{row.cost}</td>
                    <td>{row.partsDescription}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="BreakDownDetails-event">
      <div className="BreakDownDetails-event-bar">
        <div className="BreakDownDetails-event-header">
          <FaArrowCircleRight />
          <span>Break Down Details</span>
        </div>
      </div>
      <div className="BreakDownDetails-content-wrapper">
        <div className="BreakDownDetails-main-section">
          <div className="BreakDownDetails-panel dis-templates">
            <div className="BreakDownDetails-panel-header"></div>
            <div className="BreakDownDetails-panel-content">
              <div className="BreakDownDetails-form-row">
                <label>Break Down No : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Complaint Number : </label>
                <div className="BreakDownDetails-input-with-search">
                  <input type="text" value="" />

                  <CiSearch className="BreakDownDetails-magnifier-btn" />
                </div>
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Subject : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-header-contact">
                <h3>Equipment Details</h3>
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Equipment Name : *</label>
                <div className="BreakDownDetails-input-with-search">
                  <input type="text" value="" />
                  <CiSearch className="BreakDownDetails-magnifier-btn" />
                </div>
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Equipment Code : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Asset No : </label>
                <input type="text" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Manual Code : </label>
                <input type="text" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Location : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Category : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Depreciation : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Serial No : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Model No : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Responsible Person : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Compony Brand : </label>
                <input type="text" value="" />
              </div>
              <div className="BreakDownDetails-header-contact">
                <h3>Supplier Details</h3>
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Supplier Name : </label>
                <div className="BreakDownDetails-input-with-search">
                  <input type="text" value="" />
                  <CiSearch className="BreakDownDetails-magnifier-btn" />
                </div>
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Supplier Address : </label>
                <textarea name="" id=""></textarea>
              </div>
            </div>
          </div>

          <div className="BreakDownDetails-panel operation-details">
            <div className="BreakDownDetails-panel-header"></div>
            <div className="BreakDownDetails-panel-content">
              <div className="BreakDownDetails-form-row">
                <label>Contact Person : </label>
                <input type="text" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Contact Number : </label>
                <input type="tel" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Supplier E-mail: </label>
                <input type="email" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Break Down Date: </label>
                <input type="date" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Break Down Time: </label>
                <input type="time" value="" />
              </div>

              <div className="BreakDownDetails-header-contact">
                <h3>Break Down Details</h3>
              </div>

              <div className="BreakDownDetails-form-row">
                <label>BreakDown Details : </label>
                <textarea name="" id=""></textarea>
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Parts Replaced:</label>
                <select>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Compony Name : </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Invoice No : </label>
                <input type="text" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Date Of Invoice : </label>
                <input type="date" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Purchase Date Of Equipment : </label>
                <input type="date" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Purchase Cost: </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-form-row">
                <label>Complaint Status :</label>
                <select>
                  <option>Solved</option>
                  <option>Re-solved</option>
                </select>
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Work Completion Date: </label>
                <input type="date" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Work Completion Time: </label>
                <input type="time" value="" />
              </div>
              <div className="BreakDownDetails-form-row">
                <label>Contact Person: </label>
                <input type="text" value="" />
              </div>

              <div className="BreakDownDetails-header-contact">
                <h3>Document</h3>
              </div>
              <div className="BreakDownDetails-form-row">
                <input
                  type="text"
                  placeholder="File Name"
                  value={selectedFile ? selectedFile.name : ""}
                  readOnly
                />
                <div>
                  <input
                    type="file"
                    id="fileInput"
                    style={{ display: "none" }}
                    onChange={handleFileChange}
                  />
                  <label htmlFor="fileInput" className="btn-green">
                    Choose File
                  </label>
                  <button className="btn-green" onClick={handleUpload}>
                    Upload
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="BreakDownDetails-history-section">
          <div className="BreakDownDetails-tab-bar">
            <button
              className={`BreakDownDetails-tab ${
                selectedTab === "repairbleParts" ? "active" : ""
              }`}
              onClick={() => setSelectedTab("repairbleParts")}
            >
              Repairble Parts
            </button>

            <button
              className={`BreakDownDetails-tab ${
                selectedTab === "guaranteedParts" ? "active" : ""
              }`}
              onClick={() => setSelectedTab("guaranteedParts")}
            >
              Guaranteed Parts
            </button>
            <button
              className={`BreakDownDetails-tab ${
                selectedTab === "history" ? "active" : ""
              }`}
              onClick={() => setSelectedTab("history")}
            >
              Break Down History
            </button>
          </div>
          {renderTable()}
        </div>

        <div className="BreakDownDetails-action-buttons">
          <button className="btn-blue">Save</button>
          <button className="btn-red">Delete</button>
          <button className="btn-orange">Clear</button>
          <button className="btn-gray">Close</button>
          <button className="btn-blue">Search</button>
          <button className="btn-gray">Tracking</button>
          <button className="btn-green">Print</button>
          <button className="btn-blue">Export</button>
          <button className="btn-gray">Import</button>
          <button className="btn-green">Health</button>
          <button className="btn-gray">Version Comparison</button>
          <button className="btn-gray">SDC</button>
          <button className="btn-gray">Testing</button>
          <button className="btn-blue">Info</button>
        </div>
      </div>
    </div>
  );
};
export default BreakDownDetails;
