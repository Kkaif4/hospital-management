
// neha HI-report-19/09/24
import React from 'react'
import './report.css'

function Report() {
  return (
    <div className='main_report_comtainer'>
        <h1>
            Report
        </h1>
      
    </div>
  )
}

export default Report
