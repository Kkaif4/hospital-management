import React from 'react'

function Geologicalmaster() {
  return (
    <div>
      
    </div>
  )
}

export default Geologicalmaster
